"""
cube.py
===
1. Create a primitive cube in blender.
"""
