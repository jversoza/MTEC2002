"""
mad_libs.py
===
0. Create a function, mad_lib, that takes two arguments, noun and verb... and print out the noun and verb together separated by a space.
1. Rewrite mad_lib so that it takes two keyword arguments, noun and verb.
2. Set the default values as 'foo' and 'bar'.
3. In the body of the function, print out the noun and verb separated by a space.
4. Call the function with no arguments.
5. Call the function with one keyword argument.
6. Call the function with both keyword arguments.

"""
