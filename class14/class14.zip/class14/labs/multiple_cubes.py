"""
multiple_cubes.py
===
1. Use two loops to create a grid of cubes (that is, cubes that go along the x AND y axis).
2. (Intermediate) ... what if we wanted to add cubes along the third axis?
"""
