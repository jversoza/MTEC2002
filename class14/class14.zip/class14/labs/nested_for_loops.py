"""
nested_for_loops.py
===
1. Create two for loops, one nested inside the other.
2. Each loop should loop 10 times.
3. In the inner loop, print out the number of iterations that have occurred for each loop.
"""
