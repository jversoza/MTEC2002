"""
mesh_triangle.py
===
1. Create a triangle using from_pydata.
"""
