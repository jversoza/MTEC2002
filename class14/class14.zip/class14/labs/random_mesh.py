"""
random_mesh.py
===
1. Using the function from the previous exercise.
2. Create a grid of planes at varying z values.

"""
