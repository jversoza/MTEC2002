"""
loops.py
===
1. Use a loop to create 3 cubes exactly 5 units away from each other.
"""
