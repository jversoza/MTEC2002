"""
list_of_lists.py
===
1. Create a list of lists:
	list_of_lists = [['beetle', 'firefly'],['chicken', 'duck'],['shark','goldfish']]
2. Iterate over the first list with one for loop
3. Iterate over the nested lists with a nested for loop
4. Print out the elements so that the output looks like this:
beetle
firefly
chicken
duck
shark
goldfish
"""
