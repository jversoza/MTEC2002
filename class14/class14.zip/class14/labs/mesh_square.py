"""
mesh_square.py
===
1. Create a square (a plane) using the from_pydata function.
2. Follow along from previous exercises to create a mesh, create an object... and finally link to a scene.
"""
