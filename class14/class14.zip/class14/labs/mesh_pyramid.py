"""
mesh_pyramid.py
===
1. Create a pyramid using from_pydata.
"""
