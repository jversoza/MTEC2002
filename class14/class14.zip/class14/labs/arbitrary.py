"""
arbitrary.py
===
0. Create a function called ask that takes one argument... all it will do is append a question mark to the argument and print it out.
1. Rewrite ask to use an arbitrary number of arguments - that is, the parameter list should have *args in it.
2. Iterate over all of the arguments.
3. Print out each word with a question mark appended to it.
"""
