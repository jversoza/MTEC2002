"""
my_program.py
===
1. Bring in a module that you created called "my_module"
2. Call the f1 and f2 functions in my_module
"""
