"""
add_three_tested.py
=====
Create a function that takes one argument, n.  Return n with 3 added to it.  Write doc tests.

http://docs.python.org/library/doctest.html
"""


if __name__ == "__main__":
	import doctest
	doctest.testmod()
