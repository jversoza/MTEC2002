"""
add_three_tested.py
=====
Create a function that takes one argument, n.  Return n to the third power.  Write doc tests.

http://docs.python.org/library/doctest.html
"""

if __name__ == "__main__":
	import doctest
	doctest.testmod()
