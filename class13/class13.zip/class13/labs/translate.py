"""
translate.py
===
See instructions in spanish.py
"""
